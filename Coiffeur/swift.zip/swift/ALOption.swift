//
//  ALOption.swift
//  Coiffeur
//
//  Created by Anton Leuski on 3/27/15.
//  Copyright (c) 2015 Anton Leuski. All rights reserved.
//

import Foundation
import CoreData

class ALOption: ALNode {

    @NSManaged var key: String
    @NSManaged var value: String

}

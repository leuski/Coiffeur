//
//  ALNode+model.swift
//  Coiffeur
//
//  Created by Anton Leuski on 3/27/15.
//  Copyright (c) 2015 Anton Leuski. All rights reserved.
//

import Foundation

extension ALNode {
	
	class func keyPathsForValuesAffectingFilteredChildren() -> NSSet {
		return NSSet(array:["predicate", "children" ])
	}

	class func keyPathsForValuesAffectingPredicate() -> NSSet {
		return NSSet(object:"parent.predicate")
	}
	
	var tokens : NSArray {
		if let t = self.type {
			return t.componentsSeparatedByString(",")
		} else {
			return []
		}
	}

	var predicate : NSPredicate? {
		return self.parent?.predicate
	}
	
	var filteredChildren : NSSet {
		if let p = self.predicate {
			return self.children.filteredSetUsingPredicate(p)
		} else {
			return self.children
		}
	}

	var depth : Int {
		if let p = self.parent {
			return 1 + p.depth
		} else {
			return 0
		}
	}
}

extension ALRoot {
	override var predicate : NSPredicate? {
		get {
			return self.storedPredicate as NSPredicate?
		}
		set (newPredicate) {
			self.storedPredicate = newPredicate
		}
	}
	
	override var filteredChildren : NSSet {
		return self.children
	}
}